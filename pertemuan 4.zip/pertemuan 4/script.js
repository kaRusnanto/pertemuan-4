// // variabel inputan password 
// let password = prompt("password")

// // variabel untuk menghitung length/panjang dari password
// let pass_length = password.length 

// // variabel untuk mengecek length/panjang dari pass_length, jika benar "berhasil" dan jika salah maka "gagal"
// let cek = pass_length > 8 ? "berhasil" : "gagal"

// // memberikan output berupa alert
// alert(cek)

// // mencari text dalam string
// let nama = "aryazid si anak ganteng dari gua hiro"
// let cari = nama.indexOf('anak')

// // mengambil potongan text string
// let asal = "bogor, indonesia"
// let ambiltext = asal.slice(0,5)

// // mengganti text dalam string
// let matkul = "pemograman javascript"
// let ubahtext = matkul.replace("javascript", "PHP")

// // mengubah text string menjadi uppercase dan lowercase
// let kata1 = "saya anak baik"
// let kata2 = "SAYA ANAK JAHAT"
// let uppercase = kata1.toUpperCase()
// let lowercase = kata2.toLowerCase()

// // menambah text dalam string
// let mahasantri = "erik"
// let tambahtext = mahasantri.concat(" ", "pratama")

// // menampilkan output
// alert(tambahtext) 
// alert(lowercase) 

// Text 1, mengubah text string menjadi uppercase dan lowercase
let bendera = "Merah Putih"
let uppercase = bendera.toUpperCase()

// Text 2, mengubah text string menjadi lowercase
let bendera1 = "Merah Putih"
let lowercase = bendera1.toLowerCase()

//Text 3, Mengubah text dalam string
let bendera3 = "Merah Putih"
let ubahTeks = bendera3.replace("Putih", "Muda")

// Text 4, untuk menghitung panjang dari variabel Text
let bendera4 = "Merah Putih"
let output = bendera4.length


// menampilkan output
alert(uppercase) // menampilkan huruf besar
alert(lowercase) // menampilkan huruf kecil
alert(ubahTeks) // menampilkan mengubah text "putih menjadi "muda"
alert(output) // menampilkan panjang dari variabel text

